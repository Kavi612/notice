import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, UpdateCommand } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  try {
    const noticeId = event.pathParameters?.id;

    if (!noticeId) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "Notice id is required in the URL" })
      };
    }

    const body = JSON.parse(event.body);

    // Build the update expression dynamically based on what fields were sent
    const allowedFields = [
      "title", "content", "department", "category",
      "targetYear", "targetSection", "status", "template",
      "publishAt", "expiresAt"
    ];

    const updateParts = [];
    const expressionValues = {};
    const expressionNames = {};

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateParts.push(`#${field} = :${field}`);
        expressionNames[`#${field}`] = field;
        expressionValues[`:${field}`] = body[field];
      }
    }

    if (updateParts.length === 0) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "No valid fields provided to update" })
      };
    }

    // Always update updatedAt
    updateParts.push("#updatedAt = :updatedAt");
    expressionNames["#updatedAt"] = "updatedAt";
    expressionValues[":updatedAt"] = new Date().toISOString();

    const result = await docClient.send(
      new UpdateCommand({
        TableName: "Notices",
        Key: { noticeId: noticeId },
        UpdateExpression: "SET " + updateParts.join(", "),
        ExpressionAttributeNames: expressionNames,
        ExpressionAttributeValues: expressionValues,
        ReturnValues: "ALL_NEW"
      })
    );

    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(result.Attributes)
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Something went wrong updating the notice" })
    };
  }
};