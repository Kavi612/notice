import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { DynamoDBDocumentClient, PutCommand } from "@aws-sdk/lib-dynamodb";
import { randomUUID } from "crypto";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    if (!body.title || !body.content || !body.authorId) {
      return {
        statusCode: 400,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "title, content, and authorId are required" })
      };
    }

    const now = new Date().toISOString();

    const notice = {
      noticeId: randomUUID(),
      title: body.title,
      content: body.content,
      authorId: body.authorId,
      department: body.department || "General",
      category: body.category || "General",
      targetYear: body.targetYear || "All",
      targetSection: body.targetSection || "All",
      status: "DRAFT",
      template: body.template || "Formal Academic",
      createdAt: now,
      updatedAt: now
    };

    // Only add publishAt if a real value was given — never write "null"
    if (body.publishAt) {
      notice.publishAt = body.publishAt;
    }

    // Only add expiresAt if a real value was given — never write "null"
    if (body.expiresAt) {
      notice.expiresAt = body.expiresAt;
    }

    await docClient.send(
      new PutCommand({
        TableName: "Notices",
        Item: notice
      })
    );

    return {
      statusCode: 201,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(notice)
    };
  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Something went wrong creating the notice" })
    };
  }
};